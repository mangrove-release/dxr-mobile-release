import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstant } from './config/app-constant';
import { CompanyContext } from './models/backend-fetch/dxr-system';
import { UserIdentification } from './models/backend-update/user-login';
import { LanguageService } from './services/visitor-services/language.service';
import { UriService } from './services/visitor-services/uri.service';
import { UserLoginService } from './services/visitor-services/user-login.service';
import { UtilService } from './services/visitor-services/util.service';

@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit {
    constructor(private languageService: LanguageService, private router: Router, private utilService: UtilService, private uriService: UriService, private userLoginService: UserLoginService) { }

    uiLabels: any = {};
    menuList: any = [];
    selectedMenu!: String;
    isLogedIn = false;


    profileArray: any = [];
    selectedProfileItem: string = '';
    selectedProfileFunction: any;
    selectedLangIndex = this.languageService.getSelectedLanguageIndex();
    languageArray = ['jpn', 'eng'];
    selectedLanguage: string = this.utilService.getSelectedLanguageIndex() ? this.utilService.getSelectedLanguageIndex() : this.languageArray[0];
    selectedLanguageModel: string = this.selectedLanguage;
    viewContent = false;

    ngOnInit() {

        if (!this.selectedLangIndex || this.selectedLangIndex == '') {
            this.utilService.setSelectedLanguageIndex(AppConstant.LANG_INDEX_JPN);
            this.selectedLanguage = AppConstant.LANG_INDEX_JPN;
        }

        var backUrl = '/language-competency/language';
        var cacheUrl = backUrl;
        this.uriService.callBackendWithCache(backUrl, AppConstant.HTTP_GET, cacheUrl, {}, (data: any) => {
            if (data) {
                // console.log(data);
                // console.log(JSON.stringify(JSON.parse(data.languageJson)));

                this.languageService.setLanguageDefData(data.languageJson);
                this.uiLabels = this.languageService.getUiLabels(AppConstant.COMP.APP_ROOT, AppConstant.UI_LABEL_TEXT);
                this.prepareProfileItem();
            }
            this.viewContent = true;

        });
    }

    initialLogin() {

        var authId = this.utilService.getUserIdCookie();
        var authPass = this.utilService.getUserAuthPassCookie();

        if (authId && authPass) {

            var userIdentification: UserIdentification = {
                userId: authId,
                userAuth: authPass,
                oneTimeAccessFlag: ''
            }

            this.userLoginService.login(userIdentification).subscribe(data => {

                this.prepareUserAccessAndMenu(data);
            });

        } else {
            this.prepareUserAccessAndMenu();
        }

    }

    prepareUserAccessAndMenu(data?: any) {
        if (data && data.length > 0) {
            this.isLogedIn = true;
            var previouslySelectedCompanyId = this.utilService.getCompanyIdCookie();

            this.languageService.setUserAccessInfo(data);

            if (previouslySelectedCompanyId) {
                this.languageService.setCurrentContextMenuItems(data, previouslySelectedCompanyId);
            } else {
                this.languageService.setCurrentContextMenuItems(data);
            }

            this.setIsLoged(true);

        }

        this.reloadMenuList();
    }

    logOut() {

        this.utilService.clearCookie();
        this.languageService.resetUserAccessInfo();
        this.languageService.resetUserMenuItems();
        this.setIsLoged(false)
        this.reloadMenuList();

    }

    setIsLoged(status: boolean) {
        this.isLogedIn = status;
    }

    reloadMenuList() {
        this.menuList = this.languageService.getUserMenuItems();
        // this.selectedMenu = this.menuList[0].menuTitle;
        this.router.navigate(['home']);
    }

    prepareProfileItem() {
        // this.uiLabels.profile = (this.uiLabels.profile != null) ? (this.uiLabels.profile) : 'Profile';
        // this.uiLabels.switchCompany = (this.uiLabels.switchCompany != null) ? (this.uiLabels.switchCompany) : 'Switch Company';
        // this.uiLabels.changePassword = (this.uiLabels.changePassword != null) ? (this.uiLabels.changePassword) : 'Change Password';
        this.profileArray = [
            {
                title: this.uiLabels.switchCompany,
                function: this.switchCompany
            },
            {
                title: this.uiLabels.changePassword,
                function: this.changePassword
            },
        ]

        this.selectedProfileItem = this.profileArray[0].title;
    }

    profileItemClick = () => {

        var itemIndex = this.profileArray.findIndex((item: any) => (item.title == this.selectedProfileItem));

        if (itemIndex >= 0) {
            this.profileArray[itemIndex].function();
        }

    }



    switchCompany = () => {
        var currentCompanyId = this.utilService.getCompanyIdCookie();
        var currentContextInfo: CompanyContext = this.languageService.getCurrentCompany(currentCompanyId);
        var contextList: CompanyContext[] = this.languageService.getEnrolledCompanyList();

        // this.matDialog.open(SwitchContextComponent, {
        //     width: '55%',
        //     height: '75%',
        //     data: {
        //         companyContext: currentContextInfo,
        //         companyContextList: contextList
        //     }
        // })

        console.log(currentContextInfo);
        console.log(contextList);

    }

    changePassword() {
        var authId = this.utilService.getUserAuthPassCookie();
        var width: string = '';
        var height: string = '';

        width = '75%';
        height = '75%';


        // const forgetPassDialog = matDialog.open(ChangePasswordComponent, {
        //     width: width,
        //     height: height,
        //     data: {
        //         userId: authId,
        //         fromProfile: true
        //     },
        //     disableClose: true
        // });

    }
}
