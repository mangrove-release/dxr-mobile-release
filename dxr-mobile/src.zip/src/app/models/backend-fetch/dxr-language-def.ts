export interface DxrLanguageDef {

    languageCompetencyId: String,
    languageJson: String,
    backendDate: String
    frontendDate: String
    dxrInfoCache: String
}