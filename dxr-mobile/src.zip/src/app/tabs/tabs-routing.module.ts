import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Tab1PageModule } from '../tab1/tab1.module';
import { TabsPage } from './tabs.page';

const routes: Routes = [

    {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full'
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [Tab1PageModule]
})
export class TabsPageRoutingModule { }
