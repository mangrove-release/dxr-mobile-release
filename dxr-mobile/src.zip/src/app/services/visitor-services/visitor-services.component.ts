import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitor-services',
  templateUrl: './visitor-services.component.html',
  styleUrls: ['./visitor-services.component.css']
})
export class VisitorServicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
