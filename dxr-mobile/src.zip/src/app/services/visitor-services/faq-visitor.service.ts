import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { FaqTypeFetch, FaqInfoFetch } from 'src/app/models/backend-fetch/faq-fetch';
import { ThrowStmt } from '@angular/compiler';
import { UriService } from './uri.service';
import { AppConstant } from 'src/app/config/app-constant';

@Injectable({
    providedIn: 'root'
})
export class FaqVisitorService {

    constructor(private http: HttpClient, private uriService: UriService) { }

    faqType: FaqTypeFetch[] = [
        {
            faqTypeId: '1',
            faqType: "Waste",
            faqTypeDescription: "FAQ of Waste",
            backendDate: '',
            frontendDate: '',
            dxrInfoCache: ''
        },
        {
            faqTypeId: '2',
            faqType: "Dumper",
            faqTypeDescription: "FAQ of Dumper",
            backendDate: '',
            frontendDate: '',
            dxrInfoCache: ''
        },
        {
            faqTypeId: '3',
            faqType: "Transporter",
            faqTypeDescription: "FAQ of Transporter",
            backendDate: '',
            frontendDate: '',
            dxrInfoCache: ''
        },

    ];

    faqInfoList: FaqInfoFetch[] = [
        {
            faqInfoId: '1',
            faqInfoQuestion: "Which kind of waste being proccessed?",
            faqInfoAnswer: "Plasctic, Electronics, Chemicals etc.",
            faqTypeId: '1',
            backendDate: '',
            frontendDate: '',
            dxrInfoCache: ''

        },
        {
            faqInfoId: '2',
            faqInfoQuestion: "Which kind of waste being proccessed?",
            faqInfoAnswer: "Plasctic, Electronics, Chemicals etc.",
            faqTypeId: '1',
            backendDate: '',
            frontendDate: '',
            dxrInfoCache: ''
        },
        {
            faqInfoId: '3',
            faqInfoQuestion: "Which kind of waste being proccessed?",
            faqInfoAnswer: "Plasctic, Electronics, Chemicals etc.",
            faqTypeId: '1',
            backendDate: '',
            frontendDate: '',
            dxrInfoCache: ''
        }
    ];

    backendFetchHandler = {

        getFaqTypes: (): Observable<FaqTypeFetch[]> => {
            var url = '/faq/types';
            return this.uriService.callBackend(url, AppConstant.HTTP_GET);
        },

        getFaqInfoListByFaqType: (faqTypeId: String): Observable<FaqInfoFetch[]> => {

            var url = '/faq/questions/?faqType=' + faqTypeId;
            return this.uriService.callBackend(url, AppConstant.HTTP_GET);
        },
        getFaqInfoList: (): Observable<FaqInfoFetch[]> => {

            var url = '/faq/questions/all'
            return this.uriService.callBackend(url, AppConstant.HTTP_GET);
        }
    }

    fetchAdapter = {

    }
}
