import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VisitorPageRoutingModule } from './visitor-routing.module';

import { VisitorPage } from './visitor.page';
import { UserLoginComponent } from './user-login/user-login.component';
import { ChangePasswordComponent } from './change-password/change-password.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        VisitorPageRoutingModule,

    ],
    declarations: [
        VisitorPage,
        UserLoginComponent,
        ChangePasswordComponent
    ]
})
export class VisitorPageModule { }
